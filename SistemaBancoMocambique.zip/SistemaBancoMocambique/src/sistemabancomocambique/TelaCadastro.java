package sistemabancomocambique;

import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaCadastro extends javax.swing.JFrame {

    DefaultTableModel modelo;
    Scanner input = new Scanner(System.in);
    
    public TelaCadastro() {
        initComponents();
        
        modelo = new DefaultTableModel();
        
        modelo.addColumn("NOME");
        modelo.addColumn("T. DOC");
        modelo.addColumn("TELEFONE");
        modelo.addColumn("EMAIL");
        modelo.addColumn("PROVINCIA");
        modelo.addColumn("GENERO");
        modelo.addColumn("LOC. TRAB");
        modelo.addColumn("AREA.TRAB");
        
        tabelaRegistro.setModel(modelo);
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        campNome = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        combDocumentos = new javax.swing.JComboBox<>();
        campTelefone = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        campEmail = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        combProvincia = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        combGenero = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        campLocal = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        campArea = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        botaoLimpar = new javax.swing.JButton();
        botaoSalvar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelaRegistro = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        campNome.setBackground(new java.awt.Color(0, 204, 204));
        campNome.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(campNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 190, 40));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel1.setText("NOME");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        combDocumentos.setBackground(new java.awt.Color(0, 255, 255));
        combDocumentos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tipo de Documento", "BI", "CEDULA", "CARTA DE CONDUCAO", "DIRI", "CARTAO DE ELEITOR" }));
        jPanel1.add(combDocumentos, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 60, 190, 40));

        campTelefone.setBackground(new java.awt.Color(0, 204, 204));
        campTelefone.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(campTelefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 60, 190, 40));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel2.setText("Telefone");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel3.setText("T. Doc");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 70, -1, -1));

        campEmail.setBackground(new java.awt.Color(0, 204, 204));
        campEmail.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(campEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 190, 40));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel4.setText("Email");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, -1));

        combProvincia.setBackground(new java.awt.Color(0, 255, 255));
        combProvincia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione a Provincia", "MAPUTO - PROVINCIA", "MAPUTO - CIDADE", "GAZA", "INHAMBANE", "MANICA", "SOFALA", "NAMPULA", "TETE", "CABO DELGADO", "NIASSA", "ZAMBEZIA" }));
        jPanel1.add(combProvincia, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 140, 190, 40));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel5.setText("Provincia");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, -1, 20));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel6.setText("Genero");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 150, -1, -1));

        combGenero.setBackground(new java.awt.Color(0, 255, 255));
        combGenero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione Genero", "MASCULINO", "FEMENINO" }));
        jPanel1.add(combGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 140, 190, 40));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel7.setText("Loc. Traba.");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, -1, -1));

        campLocal.setBackground(new java.awt.Color(0, 204, 204));
        campLocal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(campLocal, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, 190, 40));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel8.setText("Area. Tra.");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 230, -1, -1));

        campArea.setBackground(new java.awt.Color(0, 204, 204));
        campArea.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(campArea, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 220, 190, 40));

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));
        jPanel2.setLayout(new java.awt.GridLayout(1, 0));

        botaoLimpar.setBackground(java.awt.Color.white);
        botaoLimpar.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        botaoLimpar.setText("Limpar");
        botaoLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoLimparActionPerformed(evt);
            }
        });
        jPanel2.add(botaoLimpar);

        botaoSalvar.setBackground(new java.awt.Color(255, 255, 255));
        botaoSalvar.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        botaoSalvar.setText("Salvar");
        botaoSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoSalvarActionPerformed(evt);
            }
        });
        jPanel2.add(botaoSalvar);

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 220, 190, 40));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("SISTEMA DE CADASTRO DE CLIENTES");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, 740, -1));

        tabelaRegistro.setBackground(new java.awt.Color(0, 255, 255));
        tabelaRegistro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelaRegistro.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tabelaRegistro.setGridColor(new java.awt.Color(0, 0, 0));
        tabelaRegistro.setRowHeight(20);
        jScrollPane2.setViewportView(tabelaRegistro);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 1000, 410));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setSize(new java.awt.Dimension(1019, 756));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void botaoSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoSalvarActionPerformed
        //Botao salvar
        String nome = campNome.getText().trim();
        String documento = combDocumentos.getSelectedItem().toString();
        String contacto = campTelefone.getText().trim();
        String email = campEmail.getText().trim();
        String provincia = combProvincia.getSelectedItem().toString();
        String genero = combGenero.getSelectedItem().toString();
        String local = campLocal.getText().trim();
        String area = campArea.getText().trim();

        if(nome.isEmpty() || contacto.isEmpty() || email.isEmpty() || local.isEmpty() || area.isEmpty()){
            JOptionPane.showMessageDialog(null, "PREENCHA TODOS OS CAMPOS");
        }
        else{
            modelo.addRow(new Object[] {nome, documento, contacto, email, provincia, genero, local, area});
        }
    }//GEN-LAST:event_botaoSalvarActionPerformed

    private void botaoLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoLimparActionPerformed
        campNome.setText("");
        campTelefone.setText("");
        campEmail.setText("");
        campArea.setText("");
        combDocumentos.setSelectedIndex(0);
        combProvincia.setSelectedIndex(0);
        combGenero.setSelectedIndex(0);
        campLocal.setText("");
        
    }//GEN-LAST:event_botaoLimparActionPerformed

    /**
     * @Author EdilsonVitorinoHilario
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoLimpar;
    private javax.swing.JButton botaoSalvar;
    private javax.swing.JTextField campArea;
    private javax.swing.JTextField campEmail;
    private javax.swing.JTextField campLocal;
    private javax.swing.JTextField campNome;
    private javax.swing.JTextField campTelefone;
    private javax.swing.JComboBox<String> combDocumentos;
    private javax.swing.JComboBox<String> combGenero;
    private javax.swing.JComboBox<String> combProvincia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tabelaRegistro;
    // End of variables declaration//GEN-END:variables
}
